package com.pizzeria;

public class PizzaFactory {
    private static PizzaFactory instancia;

    public static final String PIZZA_MUZZARELLA = "MUZZARELLA";
    public static final String PIZZA_ESPECIAL = "ESPECIAL";
    public static final String PIZZA_ANANA = "ANANA";
    public static final String PIZZA_LOCA = "LOCA";

    public static final Double PRECIO_MUZZARELLA = 700d;
    public static final Double PRECIO_ESPECIAL = 850d;
    public static final Double PRECIO_ANANA = 950d;

    private PizzaFactory() {

    }

    public static PizzaFactory getInstance() {
        if (instancia == null)
            instancia = new PizzaFactory();
        return instancia;
    }

    public static Pizza generarPizza(String tipo) throws PizzaFactoryException {
        switch (tipo) {
            case PIZZA_MUZZARELLA:
                return new PizzaSimple(PIZZA_MUZZARELLA, PRECIO_MUZZARELLA, false);
            case PIZZA_ESPECIAL:
                return new PizzaSimple(PIZZA_ESPECIAL, PRECIO_ESPECIAL, false);
            case PIZZA_ANANA:
                return new PizzaSimple(PIZZA_ANANA, PRECIO_ANANA, false);
            case PIZZA_LOCA:
                Pizza pizzaLoca = new PizzaCombinada(PIZZA_LOCA);
                ((PizzaCombinada) pizzaLoca).agregarPizza(PizzaFactory.generarPizza(PIZZA_ESPECIAL));
                ((PizzaCombinada) pizzaLoca).agregarPizza(PizzaFactory.generarPizza(PIZZA_ANANA));
                return pizzaLoca;
            default:
                throw new PizzaFactoryException("Código " + tipo + " inválido");
        }
    }


}
