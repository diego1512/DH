package com.pizzeria;

public class PizzaFactoryException extends Exception {

    public PizzaFactoryException(String message) {
        super(message);
    }

    @Override
    public String toString() {
        return super.getMessage();
    }
}
