package com.pizzeria;

import java.util.Locale;

public class PizzaSimple implements Pizza {

    private String nombre;
    private String descripcion;
    private Double precioBase;
    private Boolean esGrande;

    public PizzaSimple(String nombre, Double precioBase, Boolean esGrande) {
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.esGrande = esGrande;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public Double calcularPrecio() {
        if (esGrande)
            return precioBase * 2;
        return precioBase;
    }

    @Override
    public String toString() {
        String tamanio = esGrande ? "grande" : "chica";
        return String.format(
                "Pizza %s %s que tiene un precio base de %s pesos",
                getNombre().toLowerCase(), tamanio, this.calcularPrecio()
                );
    }
}
