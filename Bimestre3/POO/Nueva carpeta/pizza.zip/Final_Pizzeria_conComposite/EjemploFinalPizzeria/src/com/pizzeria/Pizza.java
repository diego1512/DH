package com.pizzeria;

public interface Pizza {
    String getNombre();
    Double calcularPrecio();
}
