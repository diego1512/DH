package com.pizzeria;

import java.util.ArrayList;
import java.util.List;

public class Pizzeria {
    private String nombre;
    private List<Pizza> pizzas;

    public Pizzeria(String nombre) {
        this.nombre = nombre;
        pizzas = new ArrayList<>();
    }

    public void agregarPizzas(String tipo) {
        try {
            pizzas.add(PizzaFactory.getInstance().generarPizza(tipo));
        } catch (PizzaFactoryException e) {
            System.out.println(e);
        }
    }

    public void mostrarPizzas() {
        System.out.println("Pizzeria \"" + nombre + "\" ofrece las siguientes pizzas: ");
        for (Pizza pizza: pizzas) {
            System.out.println(pizza.toString());
        }
    }
}
