package com.pizzeria;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PizzaCombinada implements Pizza {

    private String nombre;
    private String descripcion;
    private List<Pizza> pizzas;

    public PizzaCombinada(String nombre) {
        this.nombre = nombre;
        pizzas = new ArrayList<>();
    }

    public void agregarPizza(Pizza p) {
        this.pizzas.add(p);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public Double calcularPrecio() {
        Double total = 0d;
        for (Pizza pizza: pizzas) {
            total += pizza.calcularPrecio();
        }
        return total / pizzas.size();
    }

    @Override
    public String toString() {
        String tipoSimple = "";
        for (Pizza pizza: pizzas) {
            tipoSimple = tipoSimple.concat("mitad de " + pizza.getNombre().toLowerCase() + " ");
        }
        return String.format(
                "Pizza %s, %s, tiene un precio de %s pesos",
                getNombre().toLowerCase(), tipoSimple, this.calcularPrecio()
                );
    }
}
