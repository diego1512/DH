package com.pizzeria;

public class Test {
    public static void main(String[] args) {
        Pizzeria pizzeria = new Pizzeria("Pizza Loca");

        pizzeria.agregarPizzas(PizzaFactory.PIZZA_MUZZARELLA);
        pizzeria.agregarPizzas(PizzaFactory.PIZZA_ESPECIAL);
        pizzeria.agregarPizzas("Napo");
        pizzeria.agregarPizzas(PizzaFactory.PIZZA_ANANA);
        pizzeria.agregarPizzas("cuatro quesos");
        pizzeria.agregarPizzas(PizzaFactory.PIZZA_LOCA);

        pizzeria.mostrarPizzas();
    }
}
